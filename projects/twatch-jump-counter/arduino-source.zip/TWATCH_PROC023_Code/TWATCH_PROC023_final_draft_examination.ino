#include "twatch.h"
#include "variables.h"
#include "functions.h"

// --------------------
// Jump detection vars
// --------------------
int jumpCount = 0;
bool inAir = false;
unsigned long airTime = 0;

// Program states
bool running = false;      // counting jumps
bool paused  = false;      // paused after screen tap or auto-pause

// Thresholds for jump detection
const int TAKEOFF_THRESHOLD = 700;
const int LANDING_THRESHOLD = 300;
const unsigned long MIN_AIR_TIME = 120;

// --------------------
// Stopwatch vars
// --------------------
unsigned long workoutStart = 0; // timestamp when workout starts
unsigned long workoutTime  = 0; // accumulated workout time

// --------------------
// Countdown display
// --------------------
void countdown3s() {
    for (int i = 3; i > 0; i--) {
        clear();
        setFont(1, 255,255,255);
        cursor(70, 100);
        editor("Starting in:");
        cursor(120, 130);
        editor(i);
        delay(1000);
    }
    clear();
}

// --------------------
// Double-tap detection (screen)
// --------------------
unsigned long lastTouchTime = 0;
const unsigned long DOUBLE_TAP_DELAY = 400; // ms

bool doubleTap() {
    if (touch()) {
        unsigned long now = millis();
        if (now - lastTouchTime < DOUBLE_TAP_DELAY) {
            lastTouchTime = 0; // reset
            return true;
        }
        lastTouchTime = now;
    }
    return false;
}

// --------------------
// Double button press detection
// --------------------
unsigned long lastButtonTime = 0;
const unsigned long BUTTON_DOUBLE_DELAY = 500; // ms

bool buttonDoublePress() {
    if (button()) {
        unsigned long now = millis();
        if (now - lastButtonTime < BUTTON_DOUBLE_DELAY) {
            lastButtonTime = 0; // reset
            return true;
        }
        lastButtonTime = now;
    }
    return false;
}

// --------------------
// Auto-pause if idle for 15s
// --------------------
unsigned long lastJumpTime = 0;
const unsigned long IDLE_TIMEOUT = 15000; // 15 seconds

void autoPauseIfIdle() {
    if (running && !paused && (millis() - lastJumpTime > IDLE_TIMEOUT)) {
        paused = true;
        workoutTime += millis() - workoutStart; // pause stopwatch

        // 3 warning beeps
        for (int i = 0; i < 3; i++) {
            motor();
            delay(300);
        }
    }
}

// --------------------
void setup() 
{
    setupTWATCH();
    setupMotor(); // initialize vibration
    backlight(true);
    clear();
    setFont(1, 255,255,255);
}

// --------------------
void loop() 
{
    // --------------------
    // 1) Start program on single button press
    // --------------------
    if (!running && button()) {
        running = true;
        paused  = false;
        jumpCount = 0;
        inAir = false;
        lastJumpTime = millis();
        workoutTime = 0;
        workoutStart = millis();
        countdown3s();
    }

    // --------------------
    // 2) Pause on single screen tap
    // --------------------
    if (running && touch() && !paused) {
        paused = true;
        workoutTime += millis() - workoutStart; // pause stopwatch
        motor(); // vibrate to indicate pause
        delay(200); // simple debounce
    }

    // --------------------
    // 3) Resume on double tap
    // --------------------
    if (paused && doubleTap()) {
        paused = false;
        workoutStart = millis(); // resume stopwatch
        motor(); // vibrate to indicate resume
        lastJumpTime = millis(); // reset idle timer
    }

    // --------------------
    // 4) Reset on double button press
    // --------------------
    if (buttonDoublePress()) {
        running = false;
        paused = false;
        jumpCount = 0;
        inAir = false;
        workoutTime = 0;
        motor(); // vibrate to indicate reset
        clear();
    }

    // --------------------
    // 5) Jump detection
    // --------------------
    if (running && !paused) {
        acceleration();

        if (!inAir && absaccZ > TAKEOFF_THRESHOLD) {
            inAir = true;
            airTime = millis();
        }

        if (inAir && absaccZ < LANDING_THRESHOLD) {
            if (millis() - airTime > MIN_AIR_TIME) {
                jumpCount++;
                lastJumpTime = millis(); // update last jump time

                // Play sound on jump
                wav_generator->stop();
                wav_generator->begin(file_wav, output_wav);
                delay(30);
                wav_generator->stop();
            }
            inAir = false;
        }

        // --------------------
        // Auto-pause if idle for 15s
        // --------------------
        autoPauseIfIdle();
    }

    // --------------------
    // 6) DISPLAY
    // --------------------
    setFont(1, 255,255,255);
    clear();
    cursor(0, 0);
    editor("Jump Counter:\n");
    editor(jumpCount);

    editor("\n\nAccel Z:\n");
    editor(absaccZ);

    // --------------------
    // Stopwatch display
    // --------------------
    unsigned long displayTime = workoutTime;
    if (running && !paused) displayTime += millis() - workoutStart;
    unsigned long seconds = displayTime / 1000;
    unsigned long minutes = seconds / 60;
    seconds %= 60;

    editor("\n\nTime: ");
    editor(minutes);
    editor(":");
    if (seconds < 10) editor("0");
    editor(seconds);

    // --------------------
    // Status display
    // --------------------
    if (!running) {
        editor("\nPress button to start.");
        editor("\nTap screen to reset count.");
    } else if (paused) {
        editor("\nPaused");
        editor("\nDouble tap to resume.");
        editor("\nDouble press button to reset.");
    } else {
        editor("\nRunning");
        editor("\nTap screen to pause.");
        editor("\nDouble press button to reset.");
    }

    delay(50);
}
