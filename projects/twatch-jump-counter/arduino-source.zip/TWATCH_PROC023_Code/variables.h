#define NORMAL 0
#define CENTER 1

//in twatch.h:
//RTC_Date tnow;
//AsyncUDP udp;
//AudioOutputI2S *output_wav;
//AudioFileSourceFunction* file_wav;
//AudioGeneratorWAV* wav_generator;

unsigned long LAST_RTC_MILLIS = 0;
int width = 240;
int height = 240;
int  mouseX=0;
int  mouseY=0;
int  accX;
int  accY;
int  accZ;
int  absaccX;
int  absaccY;
int  absaccZ;
int  FONT_NUMBER = 1;
int  TEXT_ALIGN = 0;
bool SERIALOKAY   = false;
bool WIFIOKAY     = false;
int  UDPPORT      = 6000;
bool STROKE_ALLOW = true;
bool FILL_ALLOW   = true;
int  STROKE_ALPHA = 255;
int  STROKE_RED   = 255;
int  STROKE_GREEN = 255;
int  STROKE_BLUE  = 255;
int  FILL_ALPHA = 255;
int  FILL_RED   = 255;
int  FILL_GREEN = 255;
int  FILL_BLUE  = 255;
